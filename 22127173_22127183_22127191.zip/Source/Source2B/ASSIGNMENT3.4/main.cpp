#include "menu.h"

int main() {
	menu();

	std::cout << endl;
	std::cout << "Program exited.\n";
	std::system("pause");
	return 0;
}