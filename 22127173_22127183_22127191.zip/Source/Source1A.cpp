#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

using namespace std;

void createFiles(string volumeAddr, int sizeOfClusters){
  for (int i = 0; i < 100; i++){
    stringstream filename;
    filename << volumeAddr << "F" << i << ".Dat";

    ofstream ofs(filename.str());

    if (!ofs.is_open()){
      cout << "Unable to open file!" << endl;
      return;
    }
    int bytesOfClusters = sizeOfClusters * 512 * (4 - i % 4);
    int line = bytesOfClusters / 6; //each number and newline character have 6 bytes. 
    int value = 2020 + i;
    for (int j = 0; j < line; j++){
      ofs << value << endl;
    }
    ofs.close();
  }
}

int main(){
  string FATAddr = "I:/";
  string NTFSAddr = "G:/";
  string FAT32Addr = "H:/";
  createFiles(FATAddr, 8);
  //createFiles(NTFSAddr, 4);
  //createFiles(FAT32Addr, 2);

  return 0;
}